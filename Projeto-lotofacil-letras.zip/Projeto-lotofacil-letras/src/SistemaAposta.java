import java.io.IOException;

public class SistemaAposta {
    public static void main(String[] args) {
        System.out.println("Bem-vindo ao Sistema de Aposta!");
        System.out.print("Digite uma letra (A-Z): ");

        try {
            char letraAposta = (char) System.in.read();
            System.in.read(); // Quebra de linha

            if (Character.isLetter(letraAposta)) {
                letraAposta = Character.toUpperCase(letraAposta);
                char letraPremiada = 'F'; // Letra premiada, a letra do meu nome

                if (letraAposta == letraPremiada) {
                    System.out.println("Parabéns! Você ganhou R$ 500,00 reais.");
                } else {
                    System.out.println("Que pena! A letra sorteada foi: " + letraPremiada + ".");
                }
            } else {
                System.out.println("Aposta inválida.");
            }
        } catch (IOException e) {
            System.err.println("Erro de entrada/saída.");
        }
    }
}