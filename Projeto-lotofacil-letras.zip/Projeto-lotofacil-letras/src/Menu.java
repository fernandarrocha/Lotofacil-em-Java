import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Menu {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Sistema de Aposta");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new FlowLayout());
            JLabel label = new JLabel("Digite uma letra (A-Z): ");
            JTextField textField = new JTextField(1);
            JButton verificarButton = new JButton("Verificar");

            verificarButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    String input = textField.getText().toUpperCase();

                    if (input.length() == 1 && Character.isLetter(input.charAt(0))) {
                        char letraAposta = input.charAt(0);
                        char letraPremiada = 'F'; // Letra premiada

                        if (letraAposta == letraPremiada) {
                            JOptionPane.showMessageDialog(frame, "Parabéns! Você ganhou R$ 500,00 reais.");
                        } else {
                            JOptionPane.showMessageDialog(frame, "Que pena! A letra sorteada foi: " + letraPremiada + ".");
                        }
                    } else {
                        JOptionPane.showMessageDialog(frame, "Aposta inválida. Digite uma única letra de A a Z.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            panel.add(label);
            panel.add(textField);
            panel.add(verificarButton);

            frame.setLocationRelativeTo(null);
            frame.add(panel, BorderLayout.CENTER);
            frame.pack();
            frame.setVisible(true);
        });
    }
}
