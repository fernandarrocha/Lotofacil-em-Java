import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Random;

public class Interface {
    private static int[] numerosSorteados = new int[6];
    private static int[] numerosApostados;
    private static int quantidadeNumeros;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Menu da Loteria");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            JPanel menuPanel = new JPanel(new FlowLayout());
            JButton fazerApostaButton = new JButton("Fazer uma aposta");
            JButton verificarResultadosButton = new JButton("Verificar resultados");

            fazerApostaButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    fazerAposta();
                }
            });

            verificarResultadosButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    verificarApostas();
                }
            });

            menuPanel.add(fazerApostaButton);
            menuPanel.add(verificarResultadosButton);

            frame.add(menuPanel, BorderLayout.CENTER);
            frame.pack();
            // Centraliza a janela principal na tela
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    public static void fazerAposta() {
        JFrame apostaFrame = new JFrame("Fazer uma aposta");
        apostaFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        apostaFrame.setLayout(new BorderLayout());

        JPanel numerosPanel = new JPanel(new GridLayout(0, 1));
        JLabel label = new JLabel("Digite os números da sua aposta:");
        numerosPanel.add(label);

        quantidadeNumeros = 6;
        int[] numerosTemporarios = new int[quantidadeNumeros]; // Variável temporária

        for (int i = 0; i < quantidadeNumeros; i++) {
            JPanel inputPanel = new JPanel(new FlowLayout());
            JLabel numeroLabel = new JLabel((i + 1) + "º número:");
            JTextField numeroTextField = new JTextField(5);
            inputPanel.add(numeroLabel);
            inputPanel.add(numeroTextField);
            numerosPanel.add(inputPanel);

            int finalI = i;
            numeroTextField.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    try {
                        int numero = Integer.parseInt(numeroTextField.getText());
                        numerosTemporarios[finalI] = numero; // Armazena na variável temporária
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(apostaFrame, "Digite um número válido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });
        }

        JButton fazerApostaButton = new JButton("Fazer Aposta");
        fazerApostaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                apostaFrame.dispose();
                // Copia os valores da variável temporária para o array numerosApostados
                numerosApostados = Arrays.copyOf(numerosTemporarios, quantidadeNumeros);
            }
        });

        numerosPanel.add(fazerApostaButton);

        apostaFrame.add(numerosPanel, BorderLayout.CENTER);
        apostaFrame.pack();
        // Centraliza a janela de fazer aposta na tela
        apostaFrame.setLocationRelativeTo(null);
        apostaFrame.setVisible(true);
    }

    public static void verificarApostas() {
        JFrame resultadosFrame = new JFrame("Verificar resultados");
        resultadosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        resultadosFrame.setLayout(new BorderLayout());

        JPanel resultadosPanel = new JPanel(new GridLayout(0, 1));

        if (numerosSorteados[0] == 0) {
            JOptionPane.showMessageDialog(resultadosFrame, "Números sorteados ainda não estão disponíveis.", "Aviso", JOptionPane.WARNING_MESSAGE);
            resultadosFrame.dispose();
            return;
        }

        JLabel numerosSorteadosLabel = new JLabel("Números sorteados: " + Arrays.toString(numerosSorteados));
        JLabel resultadoLabel;

        int numerosCorretos = 0;
        for (int numeroApostado : numerosApostados) {
            for (int numeroSorteado : numerosSorteados) {
                if (numeroApostado == numeroSorteado) {
                    numerosCorretos++;
                    break;
                }
            }
        }

        if (numerosCorretos == quantidadeNumeros) {
            resultadoLabel = new JLabel("Parabéns! Você ganhou R$ 1.000,00");
        }

    }
}
