import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;

public class LoteriaMenu {
    private static int[] numerosSorteados = new int[6];
    private static int[] numerosApostados;
    private static int quantidadeNumeros;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            exibirMenu();
            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    fazerAposta();
                    break;
                case 2:
                    verificarApostas();
                    break;
                case 0:
                    System.out.println("Saindo do programa. Obrigado por jogar!");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        } while (opcao != 0);

        scanner.close();
    }

    public static void exibirMenu() {
        System.out.println("==== Menu da Loteria ====");
        System.out.println("1. Fazer uma aposta");
        System.out.println("2. Verificar resultados");
        System.out.println("0. Sair");
        System.out.print("Digite a opção desejada: ");
    }

    public static void fazerAposta() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("== Fazer uma aposta ==");

        // Definindo quantidade de números do sorteio
        quantidadeNumeros = 6;
        numerosApostados = new int[quantidadeNumeros];

        // Solicitando os números da aposta.
        System.out.println("Digite os números da sua aposta:");
        for (int i = 0; i < quantidadeNumeros; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            numerosApostados[i] = scanner.nextInt();
        }

        // Exibe os números da aposta.
        System.out.print("Aposta realizada: ");
        for (int numero : numerosApostados) {
            System.out.print(numero + " ");
        }
        System.out.println("\nAposta realizada com sucesso!");

        // Gerando números aleatórios.
        Random random = new Random();
        for (int i = 0; i < quantidadeNumeros; i++) {
            numerosSorteados[i] = random.nextInt(60) + 1;
        }
    }

    public static void verificarApostas() {
        System.out.println("== Verificar resultados ==");

        // Exibe os números sorteados.
        System.out.print("Números sorteados: ");
        for (int numeroSorteado : numerosSorteados) {
            System.out.print(numeroSorteado + " ");
        }
        System.out.println();

        // Verificando se os números apostados foram sorteados.
        int numerosCorretos = 0;
        for (int numeroApostado : numerosApostados) {
            for (int numeroSorteado : numerosSorteados) {
                if (numeroApostado == numeroSorteado) {
                    numerosCorretos++;
                    break;
                }
            }
        }

        // Resultados da aposta.
        if (numerosCorretos == quantidadeNumeros) {
            System.out.println("Parabéns! Você ganhou R$ 1.000,00 reais.");
        } else {
            System.out.println("Que pena! O número sorteado foi: " + Arrays.toString(numerosSorteados));
        }
    }
}
