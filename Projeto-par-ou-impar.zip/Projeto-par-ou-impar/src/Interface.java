import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Interface {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Aposta Par ou Ímpar");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            JPanel panel = new JPanel(new FlowLayout());
            JLabel label = new JLabel("Digite um número inteiro: ");
            JTextField textField = new JTextField(10);
            JButton verificarButton = new JButton("Verificar");

            verificarButton.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    try {
                        int numero = Integer.parseInt(textField.getText());

                        if (numero % 2 == 0) {
                            JOptionPane.showMessageDialog(frame, "Parabéns! Você ganhou R$ 100,00 reais.");
                        } else {
                            JOptionPane.showMessageDialog(frame, "Que pena, você perdeu! O número digitado é ímpar e a premiação foi para números pares.");
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Digite um número inteiro válido.", "Erro", JOptionPane.ERROR_MESSAGE);
                    }
                }
            });

            panel.add(label);
            panel.add(textField);
            panel.add(verificarButton);

            frame.add(panel, BorderLayout.CENTER);
            frame.pack();

            // Centraliza a janela na tela
            frame.setLocationRelativeTo(null);

            frame.setVisible(true);
        });
    }
}
