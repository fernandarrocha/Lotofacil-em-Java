import java.util.Scanner;

public class ApostaParImpar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite um número inteiro: ");
        int numero = scanner.nextInt(); // Lê o número digitado pelo usuário

        if (numero % 2 == 0) { // Verifica se é par ou ímpar.
            System.out.println("Parabéns! Você ganhou R$ 100,00 reais."); // Imprime a mensagem, caso o número digitado seja par.
        } else {
            System.out.println("Que pena, você perdeu! O número digitado é ímpar e a premiação foi para números pares."); // Imprime essa outa mensagem, caso o número seja ímpar.
        }

        scanner.close();
    }
}
